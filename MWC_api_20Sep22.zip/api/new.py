import psycopg2
from generator import *


#Create connection to Postgresql
con = psycopg2.connect(database="carbonemission",user='postgres', password='vibzsg1341994',host='localhost', port='5432')

#Cursor 
cur = con.cursor()

#Calculate AMD_Carbon_Emission
amd_carbon_emission = round((amd_power*amd_cpu_util*0.00277*4.91*4),2)

#Calculate Intel_Carbon_Emission
intel_carbon_emission = round((intel_power*intel_cpu_util*0.00277*4.91*4),2)

insert_query="""insert into mwc_test1("TimeStamp","Power_Consumption","CPU_Utilization","AMD_Carbon_Emission","Intel_Carbon_Emission","Intel_Power_Consumption","Intel_CPU_Utilization") VALUES(%s,%s,%s,%s,%s,%s,%s)"""
cur.execute(insert_query,(c_date ,amd_power , 
                            amd_cpu_util_percentage, 
                            amd_carbon_emission,
                            intel_carbon_emission,
                            intel_power,
                            intel_cpu_util_percentage))

con.commit()