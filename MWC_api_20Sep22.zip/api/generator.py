import time
import os
from datetime import datetime
import random

amd_power = random.randint(500,1000)
amd_cpu_util = random.randint(50,70)
amd_cpu_util_percentage = amd_cpu_util / 100
current_date=datetime.now()
c_date=current_date.strftime('%Y-%m-%d %H:%M:%S')
intel_power = random.randint(500,1000)
intel_cpu_util = random.randint(50,70)
intel_cpu_util_percentage = intel_cpu_util / 100
